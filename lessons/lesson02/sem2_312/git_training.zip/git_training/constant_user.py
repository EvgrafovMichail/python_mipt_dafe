import myconstants.math_constants as mcmath
import myconstants.physical_constants as mcphys

print(f"pi = {mcmath.pi}")
print(f"g = {mcphys.gravity_acc}")
