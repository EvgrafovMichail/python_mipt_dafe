gravity_acc = 9.8
universe_gas_const = 8.31
std_pressure = 101325
