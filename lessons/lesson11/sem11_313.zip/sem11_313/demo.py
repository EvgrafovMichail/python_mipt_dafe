import matplotlib.pyplot as plt

from utils import main


if __name__ == '__main__':
    with plt.style.context('ggplot'):
        main()