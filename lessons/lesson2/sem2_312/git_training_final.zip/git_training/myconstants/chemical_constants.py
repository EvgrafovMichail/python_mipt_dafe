H_mass = 1.008
He_mass = 4.003
O_mass = 15.999
O2_mass = O_mass * 2
H2O_mass = H_mass * 2 + O_mass
