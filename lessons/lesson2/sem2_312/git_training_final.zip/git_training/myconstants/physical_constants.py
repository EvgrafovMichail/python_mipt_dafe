gravity_acc = 9.8            # m / s^2
universe_gas_const = 8.31    # J / (K * mol)
std_pressure = 101325        # Pa
