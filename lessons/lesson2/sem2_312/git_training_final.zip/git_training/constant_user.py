import myconstants.math_constants as mcmath
import myconstants.physical_constants as mcphys
import myconstants.chemical_constants as mcchem

print(f"pi = {mcmath.pi}")
print(f"sqrt(pi) = {mcmath.pi ** 0.5}")
print(f"g = {mcphys.gravity_acc}")
print(f"g^2 = {mcphys.gravity_acc**2}")
print(f"M[H] = {mcchem.H_mass}")
print(f"M[He] = {mcchem.He_mass}")
print(f"M[O] = {mcchem.O_mass}")
print(f"M[O2] = {mcchem.O2_mass}")
print(f"M[H20] = {mcchem.H2O_mass}")

