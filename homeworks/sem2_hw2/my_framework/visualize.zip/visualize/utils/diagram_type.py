from enum import Enum


class Diagram_type(Enum):

    VIOLIN = 1
    HIST = 2
    BOXPLOT = 3
