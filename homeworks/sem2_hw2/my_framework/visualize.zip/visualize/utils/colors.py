from enum import Enum


class Colors(Enum):

    BLUE = "b"
    RED = "r"
    GREEN = "g"
    CEAN = "c"
    MAGENTA = "m"
    YELLOW = "y"
    BLACK = "k"
